# coding: utf-8

import os
import unittest
import logging
import time
import numpy as np
from math import factorial

import vtk
import qt
import ctk
import slicer
from slicer.ScriptedLoadableModule import *
from vtk.util import numpy_support
import SimpleITK as sitk
import sitkUtils as su

#
# CAIA
#

class CAIA(ScriptedLoadableModule):
    """Computer Aided Image Analysis Module"""
    
    def __init__(self, parent):
        ScriptedLoadableModule.__init__(self, parent)
        self.parent.title = "Computer Aided Image Analysis"
        self.parent.categories = ["Imaging"]
        self.parent.dependencies = []
        self.parent.contributors = ["Cyril JAUDET, PhD and Aurelien CORROYER-DULMONT, PhD (Medical Physics, Centre Francois Baclesse, CAEN, FRANCE)"]
        self.parent.helpText = """
        This module provides tools for computer-aided image analysis, particularly for nuclear medicine imaging.
        It performs CT-to-CT registration and applies the transform to nuclear medicine images, as well as FWHM analysis.
        """
        self.parent.acknowledgementText = """
        Medical Physics department, Centre Francois Baclesse, CAEN, FRANCE.
        """

#
# CAIAWidget
#

class CAIAWidget(ScriptedLoadableModuleWidget):
    """Interface class for the CAIA module"""
    
    def setup(self):
        ScriptedLoadableModuleWidget.setup(self)

        # Main parameters Area
        parametersCollapsibleButton = ctk.ctkCollapsibleButton()
        parametersCollapsibleButton.text = "Main parameters"
        self.layout.addWidget(parametersCollapsibleButton)
        parametersFormLayout = qt.QFormLayout(parametersCollapsibleButton)

        # Input volume selector - Nuclear Medicine Image to analyse
        self.inputSelectorNuclMedImgRaw = slicer.qMRMLNodeComboBox()
        self.inputSelectorNuclMedImgRaw.nodeTypes = ["vtkMRMLScalarVolumeNode"]
        self.inputSelectorNuclMedImgRaw.selectNodeUponCreation = True
        self.inputSelectorNuclMedImgRaw.addEnabled = False
        self.inputSelectorNuclMedImgRaw.removeEnabled = False
        self.inputSelectorNuclMedImgRaw.noneEnabled = False
        self.inputSelectorNuclMedImgRaw.showHidden = False
        self.inputSelectorNuclMedImgRaw.showChildNodeTypes = False
        self.inputSelectorNuclMedImgRaw.setMRMLScene(slicer.mrmlScene)
        self.inputSelectorNuclMedImgRaw.setToolTip("Pick the nuclear medicine image to analyze.")
        parametersFormLayout.addRow("Nuclear Medicine Image to analyse: ", self.inputSelectorNuclMedImgRaw)
        
        # Input volume selector - Ideal Nuclear Medicine Image
        self.inputSelectorNuclMedImgIdeal = slicer.qMRMLNodeComboBox()
        self.inputSelectorNuclMedImgIdeal.nodeTypes = ["vtkMRMLScalarVolumeNode"]
        self.inputSelectorNuclMedImgIdeal.selectNodeUponCreation = True
        self.inputSelectorNuclMedImgIdeal.addEnabled = False
        self.inputSelectorNuclMedImgIdeal.removeEnabled = False
        self.inputSelectorNuclMedImgIdeal.noneEnabled = False
        self.inputSelectorNuclMedImgIdeal.showHidden = False
        self.inputSelectorNuclMedImgIdeal.showChildNodeTypes = False
        self.inputSelectorNuclMedImgIdeal.setMRMLScene(slicer.mrmlScene)
        self.inputSelectorNuclMedImgIdeal.setToolTip("Pick the ideal nuclear medicine image.")
        parametersFormLayout.addRow("Ideal Nuclear Medicine Image: ", self.inputSelectorNuclMedImgIdeal)
        
        # Input volume selector - CT Reference
        self.inputSelectorCT_Ref = slicer.qMRMLNodeComboBox()
        self.inputSelectorCT_Ref.nodeTypes = ["vtkMRMLScalarVolumeNode"]
        self.inputSelectorCT_Ref.selectNodeUponCreation = True
        self.inputSelectorCT_Ref.addEnabled = False
        self.inputSelectorCT_Ref.removeEnabled = False
        self.inputSelectorCT_Ref.noneEnabled = False
        self.inputSelectorCT_Ref.showHidden = False
        self.inputSelectorCT_Ref.showChildNodeTypes = False
        self.inputSelectorCT_Ref.setMRMLScene(slicer.mrmlScene)
        self.inputSelectorCT_Ref.setToolTip("Pick the reference CT image.")
        parametersFormLayout.addRow("CT Reference: ", self.inputSelectorCT_Ref)
        
        # Input volume selector - CT New
        self.inputSelectorCT_New = slicer.qMRMLNodeComboBox()
        self.inputSelectorCT_New.nodeTypes = ["vtkMRMLScalarVolumeNode"]
        self.inputSelectorCT_New.selectNodeUponCreation = True
        self.inputSelectorCT_New.addEnabled = False
        self.inputSelectorCT_New.removeEnabled = False
        self.inputSelectorCT_New.noneEnabled = False
        self.inputSelectorCT_New.showHidden = False
        self.inputSelectorCT_New.showChildNodeTypes = False
        self.inputSelectorCT_New.setMRMLScene(slicer.mrmlScene)
        self.inputSelectorCT_New.setToolTip("Pick the new CT image.")
        parametersFormLayout.addRow("CT New: ", self.inputSelectorCT_New)
        
        # Input volume selector - Mask Image
        self.inputSelectorMaskImg = slicer.qMRMLNodeComboBox()
        self.inputSelectorMaskImg.nodeTypes = ["vtkMRMLLabelMapVolumeNode"]
        self.inputSelectorMaskImg.selectNodeUponCreation = True
        self.inputSelectorMaskImg.addEnabled = False
        self.inputSelectorMaskImg.removeEnabled = False
        self.inputSelectorMaskImg.noneEnabled = False
        self.inputSelectorMaskImg.showHidden = False
        self.inputSelectorMaskImg.showChildNodeTypes = False
        self.inputSelectorMaskImg.setMRMLScene(slicer.mrmlScene)
        self.inputSelectorMaskImg.setToolTip("Pick the mask image.")
        parametersFormLayout.addRow("Mask Image: ", self.inputSelectorMaskImg)

        # Input volume selector - Label Volume Ideal
        self.inputSelectorLabelVolumeIdeal = slicer.qMRMLNodeComboBox()
        self.inputSelectorLabelVolumeIdeal.nodeTypes = ["vtkMRMLLabelMapVolumeNode"]
        self.inputSelectorLabelVolumeIdeal.selectNodeUponCreation = True
        self.inputSelectorLabelVolumeIdeal.addEnabled = False
        self.inputSelectorLabelVolumeIdeal.removeEnabled = False
        self.inputSelectorLabelVolumeIdeal.noneEnabled = False
        self.inputSelectorLabelVolumeIdeal.showHidden = False
        self.inputSelectorLabelVolumeIdeal.showChildNodeTypes = False
        self.inputSelectorLabelVolumeIdeal.setMRMLScene(slicer.mrmlScene)
        self.inputSelectorLabelVolumeIdeal.setToolTip("Pick the ideal label volume.")
        parametersFormLayout.addRow("Label Volume Ideal: ", self.inputSelectorLabelVolumeIdeal)

        # Series Name
        label_NomSerie = qt.QLabel("Series Name: ")
        self.NomSerie = qt.QLineEdit()
        self.NomSerie.text = "SeriesName"
        self.NomSerie.setToolTip("Name of the series.")
        parametersFormLayout.addRow(label_NomSerie, self.NomSerie)

        # Image Sampling Percentage CT for Registration
        label_ImageSamplingPercentageCT = qt.QLabel("Image Sampling Percentage CT for Registration (%): ")
        self.ImageSamplingPercentageCT = qt.QLineEdit()
        self.ImageSamplingPercentageCT.text = "5"
        self.ImageSamplingPercentageCT.setToolTip("Percentage of image voxels used for CT registration.")
        parametersFormLayout.addRow(label_ImageSamplingPercentageCT, self.ImageSamplingPercentageCT)

        # Image Sampling Percentage
        label_ImageSamplingPercentage = qt.QLabel("Image Sampling Percentage (%): ")
        self.ImageSamplingPercentage = qt.QLineEdit()
        self.ImageSamplingPercentage.text = "5"
        self.ImageSamplingPercentage.setToolTip("Percentage of image voxels used for registration.")
        parametersFormLayout.addRow(label_ImageSamplingPercentage, self.ImageSamplingPercentage)
        
        # Output directory selector
        label_OutputDirectory = qt.QLabel("Output Directory: ")
        self.OutputDirectory = ctk.ctkPathLineEdit()
        self.OutputDirectory.filters = ctk.ctkPathLineEdit.Dirs
        self.OutputDirectory.setToolTip("Select the directory where to save results.")
        parametersFormLayout.addRow(label_OutputDirectory, self.OutputDirectory)
        
        # Registration Button
        self.RegistrationButton = qt.QPushButton("CT Registration")
        self.RegistrationButton.toolTip = "Run the CT registration algorithm."
        self.RegistrationButton.enabled = False
        parametersFormLayout.addRow(self.RegistrationButton)

        # Resolution Analysis parameters Area
        parametersCollapsibleButton2 = ctk.ctkCollapsibleButton()
        parametersCollapsibleButton2.text = "Resolution Analysis parameters"
        self.layout.addWidget(parametersCollapsibleButton2)
        parametersFormLayout2 = qt.QFormLayout(parametersCollapsibleButton2)

        # FWHM Lower Limit Button
        label_FWHM_borneInf = qt.QLabel("FWHM Lower Limit (mm): ")
        self.FWHM_borneInf = qt.QLineEdit()
        self.FWHM_borneInf.text = "3"
        self.FWHM_borneInf.setToolTip("Lower limit of the FWHM research. Range = [3-10].")
        parametersFormLayout2.addRow(label_FWHM_borneInf, self.FWHM_borneInf)

        # Resolution Button
        label_precision = qt.QLabel("Resolution (mm): ")
        self.precision = qt.QLineEdit()
        self.precision.text = "0.1"
        self.precision.setToolTip("Resolution of the FWHM research. Range = [0.01-1].")
        parametersFormLayout2.addRow(label_precision, self.precision)
        
        # Number of iterations
        label_Niteration = qt.QLabel("Number of iterations: ")
        self.Niteration = qt.QLineEdit()
        self.Niteration.text = "100"
        self.Niteration.setToolTip("Number of iterations for optimization.")
        parametersFormLayout2.addRow(label_Niteration, self.Niteration)
        
        # Window size for Savitzky-Golay filter
        label_window_size = qt.QLabel("Window size: ")
        self.window_size = qt.QLineEdit()
        self.window_size.text = "5"
        self.window_size.setToolTip("Window size for Savitzky-Golay filter.")
        parametersFormLayout2.addRow(label_window_size, self.window_size)
        
        # Number of spheres
        label_SphereNumber = qt.QLabel("Number of spheres: ")
        self.SphereNumber = qt.QLineEdit()
        self.SphereNumber.text = "6"
        self.SphereNumber.setToolTip("Number of spheres in the phantoms.")
        parametersFormLayout2.addRow(label_SphereNumber, self.SphereNumber)
        
        # Sphere volumes
        label_volume_sphere = qt.QLabel("Sphere volumes (ml): ")
        self.volume_sphere = qt.QLineEdit()
        self.volume_sphere.text = "26.52,11.49,5.57,2.57,1.15,0.52"
        self.volume_sphere.setToolTip("Volumes of the spheres in ml, comma-separated.")
        parametersFormLayout2.addRow(label_volume_sphere, self.volume_sphere)
        
        # Apply Button
        self.applyButton = qt.QPushButton("Apply")
        self.applyButton.toolTip = "Run the algorithm."
        self.applyButton.enabled = False
        parametersFormLayout2.addRow(self.applyButton)
        
        # Connect buttons to actions
        self.applyButton.connect('clicked(bool)', self.onApplyButton)
        self.RegistrationButton.connect('clicked(bool)', self.onRegistrationButton)
        
        # Connect select events to enable/disable buttons
        self.inputSelectorNuclMedImgRaw.connect("currentNodeChanged(vtkMRMLNode*)", self.onSelect)
        self.inputSelectorNuclMedImgIdeal.connect("currentNodeChanged(vtkMRMLNode*)", self.onSelect)
        self.inputSelectorMaskImg.connect("currentNodeChanged(vtkMRMLNode*)", self.onSelect)
        self.inputSelectorLabelVolumeIdeal.connect("currentNodeChanged(vtkMRMLNode*)", self.onSelect)
        self.inputSelectorCT_Ref.connect("currentNodeChanged(vtkMRMLNode*)", self.onSelect)
        self.inputSelectorCT_New.connect("currentNodeChanged(vtkMRMLNode*)", self.onSelect)
        
        # Add vertical spacer
        self.layout.addStretch(1)

    def cleanup(self):
        pass

    def onSelect(self):
        # Enable/disable Apply button based on selected inputs
        self.applyButton.enabled = (self.inputSelectorNuclMedImgRaw.currentNode() and 
                                  self.inputSelectorNuclMedImgIdeal.currentNode() and 
                                  self.inputSelectorMaskImg.currentNode() and 
                                  self.inputSelectorLabelVolumeIdeal.currentNode())
        
        # Enable/disable Registration button based on selected inputs
        self.RegistrationButton.enabled = (self.inputSelectorNuclMedImgRaw.currentNode() and 
                                         self.inputSelectorCT_Ref.currentNode() and 
                                         self.inputSelectorCT_New.currentNode())

    def onApplyButton(self):
        # Run the analysis algorithm
        logic = CAIALogic()
        try:
            logic.run(
                self.inputSelectorNuclMedImgRaw.currentNode(), 
                self.inputSelectorNuclMedImgIdeal.currentNode(), 
                self.inputSelectorMaskImg.currentNode(), 
                self.inputSelectorLabelVolumeIdeal.currentNode(), 
                self.NomSerie.text, 
                self.OutputDirectory.currentPath, 
                self.FWHM_borneInf.text, 
                self.precision.text, 
                self.Niteration.text, 
                self.window_size.text, 
                self.SphereNumber.text, 
                self.ImageSamplingPercentage.text, 
                self.volume_sphere.text
            )
        except Exception as e:
            slicer.util.errorDisplay(f"Error executing analysis: {str(e)}")
            import traceback
            traceback.print_exc()

    def onRegistrationButton(self):
        # Run the registration algorithm
        logic = CAIALogic()
        try:
            logic.registration(
                self.inputSelectorNuclMedImgRaw.currentNode(), 
                self.inputSelectorCT_Ref.currentNode(), 
                self.inputSelectorCT_New.currentNode(), 
                self.ImageSamplingPercentageCT.text, 
                self.NomSerie
            )
        except Exception as e:
            slicer.util.errorDisplay(f"Error executing registration: {str(e)}")
            import traceback
            traceback.print_exc()

#
# CAIALogic
#
class CAIALogic(ScriptedLoadableModuleLogic):
    """
    Logic class for CAIA module
    """
    
    def __init__(self):
        ScriptedLoadableModuleLogic.__init__(self)
    
    def GaussianSmoothing(self, image, FWHM):
        """Apply Gaussian smoothing with specified FWHM"""
        # Convert FWHM to sigma (FWHM = 2.355 * sigma)
        sigma = [float(FWHM) / (image.GetSpacing()[i] * 2.355) for i in range(3)]
        return sitk.SmoothingRecursiveGaussian(image, sigma)
    
    def histMatch(self, image_1, image_2):
        """Match histogram of image_2 to image_1"""
        # Cast to float64
        image_1 = sitk.Cast(image_1, sitk.sitkFloat64)
        image_2 = sitk.Cast(image_2, sitk.sitkFloat64)
        
        # Configure histogram matching filter
        histMatchFilter = sitk.HistogramMatchingImageFilter()
        histMatchFilter.SetNumberOfHistogramLevels(64)
        histMatchFilter.SetThresholdAtMeanIntensity(False)
        
        # Execute matching (source, reference)
        matched_image = histMatchFilter.Execute(image_2, image_1)
        
        return matched_image
    
    def multires_registration(self, fixed_image, moving_image, initial_transform, ImageSamplingPercentage):
        """Perform multi-resolution registration"""
        registration_method = sitk.ImageRegistrationMethod()
        registration_method.SetMetricAsMattesMutualInformation(numberOfHistogramBins=50)
        registration_method.SetMetricSamplingStrategy(registration_method.RANDOM)
        registration_method.SetMetricSamplingPercentage(float(ImageSamplingPercentage) / 100)
        registration_method.SetInterpolator(sitk.sitkLinear)
        
        # Configure optimizer
        registration_method.SetOptimizerAsGradientDescent(
            learningRate=1.0, 
            numberOfIterations=100, 
            estimateLearningRate=registration_method.EachIteration
        )
        
        registration_method.SetOptimizerScalesFromPhysicalShift()
        registration_method.SetInitialTransform(initial_transform)
        
        # Set multi-resolution parameters
        registration_method.SetShrinkFactorsPerLevel(shrinkFactors=[4, 2, 1])
        registration_method.SetSmoothingSigmasPerLevel(smoothingSigmas=[2, 1, 0])
        registration_method.SmoothingSigmasAreSpecifiedInPhysicalUnitsOn()
        
        # Execute registration
        final_transform = registration_method.Execute(fixed_image, moving_image)
        
        return final_transform
    
    def recalagerigid_Euler3Dtransform(self, image_ref, image_mobile, ImageSamplingPercentage):
        """Perform rigid registration with Euler3D transform"""
        # Convert to float for better precision in registration
        image_ref = sitk.Cast(image_ref, sitk.sitkFloat64)
        image_mobile = sitk.Cast(image_mobile, sitk.sitkFloat64)
        
        # Create initial transform
        initial_transform = sitk.Euler3DTransform()
        
        # Run multiresolution registration
        final_transform = self.multires_registration(
            image_ref,
            image_mobile,
            initial_transform,
            ImageSamplingPercentage
        )
        
        return final_transform
    
    def reechantillonage(self, image_ref, image_mobile, transform, defaultValue=0):
        """Resample an image according to reference image and transform"""
        resampler = sitk.ResampleImageFilter()
        resampler.SetReferenceImage(image_ref)
        resampler.SetInterpolator(sitk.sitkLinear)
        resampler.SetDefaultPixelValue(defaultValue)
        resampler.SetTransform(transform)
        
        image_resampled = resampler.Execute(image_mobile)
        return image_resampled
    
    def cropImagefctLabel(self, image, LowerBoundingBox, UpperBoundingBox):
        """Crop an image according to bounding box parameters"""
        # Create extraction region
        extraction_region = sitk.RegionOfInterest(
            image, 
            size=[UpperBoundingBox[0] - LowerBoundingBox[0],
                  UpperBoundingBox[1] - LowerBoundingBox[1],
                  UpperBoundingBox[2] - LowerBoundingBox[2]],
            index=[LowerBoundingBox[0], LowerBoundingBox[1], LowerBoundingBox[2]]
        )
        
        return extraction_region
    
    def registration(self, inputSelectorNuclMedImgRaw, inputSelectorCT_Ref, inputSelectorCT_New, ImageSamplingPercentageCT, NomSerie):
        """
        Perform registration between CT images and apply transform to nuclear medicine image
        """
        logging.info('Starting CT registration process')
        
        # Extract image data from Slicer
        image = su.PullFromSlicer(inputSelectorNuclMedImgRaw)
        NomSerie_text = str(NomSerie.text)
        image_CT_REF = su.PullFromSlicer(inputSelectorCT_Ref)
        image_CT_mesure = su.PullFromSlicer(inputSelectorCT_New)
        ImageSamplingPercentageCT_value = float(ImageSamplingPercentageCT)
        
        # Perform CT registration
        result_image = self.main_recalage_CT(
            image_CT_mesure, 
            image_CT_REF, 
            image, 
            ImageSamplingPercentageCT_value,
            NomSerie_text
        )
        
        # Push the registered image back to Slicer
        registered_name = inputSelectorNuclMedImgRaw.GetName() + "_recalerAvecTDM"
        su.PushToSlicer(result_image, registered_name)
        
        logging.info('CT registration completed')
        slicer.util.messageBox("Registration completed successfully. The registered image has been added to the scene as: " + registered_name)
        return "True"
    
    def main_recalage_CT(self, image_CT_mesure, image_CT_REF, image_MN_raw, ImageSamplingPercentage, nom_serie):
        """
        Perform CT-CT registration and apply transform to nuclear medicine image
        """
        logging.info("Starting CT/CT registration")
        
        # Perform registration between CT images
        transform = self.recalagerigid_Euler3Dtransform(
            image_CT_REF,
            image_CT_mesure, 
            ImageSamplingPercentage
        )
        
        logging.info("CT/CT registration completed")
        
        # Resample the nuclear medicine image with the transform
        logging.info("Applying transform to nuclear medicine image")
        image_MN_recaler = self.reechantillonage(
            image_CT_REF,
            image_MN_raw,
            transform,
            defaultValue=0
        )
        
        logging.info("Nuclear medicine image resampled with CT transform")
        
        # Return the registered nuclear medicine image
        return image_MN_recaler
    
    def savitzky_golay(self, y, window_size, order, deriv=0, rate=1):
        """Apply Savitzky-Golay filter to smooth data"""
        try:
            window_size = np.abs(np.int(window_size))
            order = np.abs(np.int(order))
        except ValueError:
            raise ValueError("window_size and order must be of type int")
        
        if window_size % 2 != 1 or window_size < 1:
            raise TypeError("window_size must be a positive odd number")
            
        if window_size < order + 2:
            raise TypeError("window_size is too small for the polynomial order")
            
        # Precompute coefficients
        order_range = range(order+1)
        half_window = (window_size - 1) // 2
        
        # Construct design matrix A
        A = np.zeros((window_size, order+1))
        for i in range(window_size):
            for j in order_range:
                A[i, j] = (i - half_window) ** j
                
        # Compute coefficients
        ATA = A.T @ A
        if np.linalg.det(ATA) < 1e-10:
            # Handle near-singular matrix
            B = np.linalg.pinv(ATA) @ A.T
        else:
            B = np.linalg.inv(ATA) @ A.T
        
        m = np.linalg.matrix_rank(A)
        
        # Compute derivatives
        if deriv > m:
            raise ValueError("The derivative order requested exceeds the polynomial order")
            
        # Compute the requested derivatives
        coeffs = np.zeros(window_size)
        for i in range(deriv, order+1):
            # Note: we need to scale by the factorial factor correctly
            coeffs += B[i] * np.power(rate, i) * factorial(i) / factorial(i - deriv)
        
        # Apply filter to input signal
        # First, handle the edges with reflections
        firstvals = y[0] - np.abs(y[1:half_window+1][::-1] - y[0])
        lastvals = y[-1] + np.abs(y[-half_window-1:-1][::-1] - y[-1])
        y_extended = np.concatenate((firstvals, y, lastvals))
        
        # Now filter
        filtered = np.convolve(y_extended, coeffs[::-1], mode='valid')
        
        return filtered
    
    def evaluateMetric(self, image1, image2, maskImage):
        """Evaluate similarity metric between two images within a mask region"""
        # Cast to float64 for metric calculation
        image1 = sitk.Cast(image1, sitk.sitkFloat64)
        image2 = sitk.Cast(image2, sitk.sitkFloat64)
        
        # Extract mask
        mask = sitk.Cast(maskImage, sitk.sitkUInt8)
        
        # Initialize metric
        metric = sitk.MattesMutualInformationImageToImageMetricv4()
        metric.SetFixedImage(image1)
        metric.SetMovingImage(image2)
        metric.SetFixedImageMask(mask)
        
        # Set up required components
        identity_transform = sitk.TranslationTransform(3, [0.0, 0.0, 0.0])
        metric.SetMovingTransform(identity_transform)
        metric.SetUseFixedImageGradientFilter(True)
        metric.SetUseMovingImageGradientFilter(True)
        
        # Initialize metric
        metric.Initialize()
        
        # Calculate and return metric value
        return metric.GetValue()
    
    def analyse_image_FWHM(self, image, image_ideal, image_MASK, FWHM_borneInf, Niteration, precision, window_size, Nspheres):
        """Analyze image FWHM"""
        logging.info("Starting FWHM analysis")
        
        # Initialize array of FWHM values to test
        FWHM_range = np.arange(FWHM_borneInf, FWHM_borneInf + Niteration * precision, precision)
        metric_values = np.zeros(Niteration)
        
        # Calculate metric for each FWHM value
        for i in range(Niteration):
            FWHM_value = FWHM_range[i]
            logging.info(f"Testing FWHM: {FWHM_value:.2f} mm")
            
            # Apply gaussian smoothing
            smoothed_image = self.GaussianSmoothing(image, FWHM_value)
            
            # Match histograms
            matched_image = self.histMatch(image_ideal, smoothed_image)
            
            # Evaluate metric
            metric_value = self.evaluateMetric(image_ideal, matched_image, image_MASK)
            metric_values[i] = metric_value
            
            logging.info(f"FWHM: {FWHM_value:.2f} mm, Metric: {metric_value:.6f}")
        
        # Apply Savitzky-Golay filter to smooth metric values
        smoothed_metrics = self.savitzky_golay(metric_values, window_size, 3)
        
        # Find optimal FWHM (minimum of smoothed metric)
        optimal_index = np.argmin(smoothed_metrics)
        optimal_FWHM = FWHM_range[optimal_index]
        
        logging.info(f"Optimal FWHM found: {optimal_FWHM:.2f} mm")
        
        return optimal_FWHM
    
    def creation_LabelAvecVolumeSphereConnu(self, image, label_ideal_volume, volume_sphere_ml, Nspheres):
        """Create label with known sphere volumes"""
        logging.info("Creating ideal label based on known sphere volumes")
        
        # Cast label to uint8 for binary operations
        labelPET = sitk.Cast(label_ideal_volume, sitk.sitkUInt8)
        imagePET = sitk.Cast(image, sitk.sitkFloat64)
        
        # Get label statistics
        labelStats = sitk.LabelStatisticsImageFilter()
        labelStats.Execute(imagePET, labelPET)
        
        # Get voxel volume in ml
        spacing = imagePET.GetSpacing()
        voxel_volume_ml = spacing[0] * spacing[1] * spacing[2] / 1000.0  # in ml
        
        # Convert volumes from ml to voxels
        volume_sphere_voxel = np.array(volume_sphere_ml) / voxel_volume_ml
        
        # Initialize arrays
        threshold = np.zeros(Nspheres + 1)
        volume_threshold = np.zeros(Nspheres + 1)
        
        # Process each label
        delta = 0
        nval = np.zeros(Nspheres + 1, dtype=int)
        nval_total = 0
        
        for label in range(1, Nspheres + 1):
            # Get label bounding box
            bounding_box = labelStats.GetBoundingBox(label)
            
            # Extract region of interest
            lower_bounds = [bounding_box[0], bounding_box[2], bounding_box[4]]
            upper_bounds = [bounding_box[1], bounding_box[3], bounding_box[5]]
            
            # Extract label region
            cropped_label = self.cropImagefctLabel(labelPET, lower_bounds, upper_bounds)
            cropped_image = self.cropImagefctLabel(imagePET, lower_bounds, upper_bounds)
            
            # Get coordinates of labeled voxels
            label_array = sitk.GetArrayFromImage(cropped_label)
            indices = np.where(label_array > 0)
            
            # Get corresponding intensity values
            intensities = sitk.GetArrayFromImage(cropped_image)[indices]
            
            # Sort intensities in descending order
            sorted_indices = np.argsort(intensities)[::-1]
            sorted_intensities = intensities[sorted_indices]
            
            # Store coordinates and values
            nval[label] = len(sorted_intensities)
            nval_total += nval[label]
            
            # Create array of coordinates and label values
            if label == 1:
                label_coordinate_sort = np.zeros((nval_total, 4))
            
            # Store coordinates in original image space
            for idx, i in enumerate(sorted_indices):
                z, y, x = indices[0][i], indices[1][i], indices[2][i]
                # Convert back to original image coordinates
                orig_x = x + lower_bounds[0]
                orig_y = y + lower_bounds[1]
                orig_z = z + lower_bounds[2]
                # Store coordinates and label
                label_coordinate_sort[idx + delta, 0] = orig_x
                label_coordinate_sort[idx + delta, 1] = orig_y
                label_coordinate_sort[idx + delta, 2] = orig_z
                label_coordinate_sort[idx + delta, 3] = label
            
            # Find threshold for the target volume
            for i in range(int(nval[label])):
                if i >= int(volume_sphere_voxel[label - 1]):
                    threshold[label] = sorted_intensities[i]
                    break
            
            # Apply threshold to labeled voxels
            volume_threshold[label] = 0
            for i in range(int(nval[label])):
                x, y, z = int(label_coordinate_sort[i+delta, 0]), int(label_coordinate_sort[i+delta, 1]), int(label_coordinate_sort[i+delta, 2])
                if imagePET.GetPixel(x, y, z) < threshold[label]:
                    label_coordinate_sort[i+delta, 3] = 0
                else:
                    volume_threshold[label] += 1
            
            delta += int(nval[label])
        
        logging.info(f"Target volumes (voxels): {volume_sphere_voxel}")
        logging.info(f"Achieved volumes (voxels): {volume_threshold}")
        
        # Create output label image
        label_ideal_tep = sitk.Multiply(labelPET, 0)
        
        # Fill output label with thresholded values
        for i in range(nval_total):
            x, y, z = int(label_coordinate_sort[i, 0]), int(label_coordinate_sort[i, 1]), int(label_coordinate_sort[i, 2])
            label_ideal_tep.SetPixel(x, y, z, int(label_coordinate_sort[i, 3]))
        
        # Push to Slicer for visualization
        su.PushToSlicer(label_ideal_tep, "ImageSeuilIdeal_Verification")
        
        return sitk.Cast(label_ideal_tep, sitk.sitkUInt8)
    
    def run(self, inputSelectorNuclMedImgRaw, inputSelectorNuclMedImgIdeal, inputSelectorMaskImg, 
            inputSelectorLabelVolumeIdeal, NomSerie, OutputDirectory, FWHM_borneInf, precision, 
            Niteration, window_size, SphereNumber, ImageSamplingPercentage, volume_sphere):
        """
        Main processing function
        """
        logging.info('Starting processing')
        
        # Extract parameters
        nom_image = inputSelectorNuclMedImgRaw.GetName()
        nom_image_ideal = inputSelectorNuclMedImgIdeal.GetName()
        nom_mask = inputSelectorMaskImg.GetName()
        savepath = str(OutputDirectory) + "/analyse.csv"
        nom_label_ideal_volume = inputSelectorLabelVolumeIdeal.GetName()
        nom_serie = str(NomSerie)
        
        precision_value = float(precision)
        Niteration_value = int(Niteration)
        FWHM_borneInf_value = int(FWHM_borneInf)
        window_size_value = int(window_size)
        
        Nspheres = int(SphereNumber)
        ImageSamplingPercentage_value = float(ImageSamplingPercentage)
        volume_sphere_values = np.fromstring(volume_sphere, dtype=float, count=-1, sep=',')
        
        # Get appropriate input image - check if registered version exists
        registered_name = nom_image + "_recalerAvecTDM"
        if slicer.util.getNode(registered_name):
            logging.info(f"Found registered image: {registered_name}")
            image = su.PullFromSlicer(registered_name)
        else:
            image = su.PullFromSlicer(nom_image)
        
        # Pull other required images
        image_ideal = su.PullFromSlicer(nom_image_ideal)
        image_MASK = su.PullFromSlicer(nom_mask)
        label_ideal_volume = su.PullFromSlicer(nom_label_ideal_volume)
        
        # Cast images to appropriate types
        image = sitk.Cast(image, sitk.sitkFloat64)
        image_ideal = sitk.Cast(image_ideal, sitk.sitkFloat64)
        
        # Create output file if it doesn't exist
        if not os.path.exists(savepath):
            with open(savepath, 'w') as f:
                f.write("Series,Image,FWHM(mm)\n")
        
        # Create label with known sphere volumes
        ideal_fct_volume = self.creation_LabelAvecVolumeSphereConnu(
            image,
            label_ideal_volume,
            volume_sphere_values,
            Nspheres
        )
        
        # Perform FWHM analysis
        fwhm_result = self.analyse_image_FWHM(
            image,
            image_ideal,
            image_MASK,
            FWHM_borneInf_value,
            Niteration_value,
            precision_value,
            window_size_value,
            Nspheres
        )
        
        # Save results
        with open(savepath, 'a') as f:
            f.write(f"{nom_serie},{nom_image},{fwhm_result:.2f}\n")
        
        logging.info(f"FWHM result: {fwhm_result:.2f}")
        
        # Push results back to Slicer for visualization
        su.PushToSlicer(ideal_fct_volume, "IdealVolumeLabel")
        
        slicer.util.messageBox(f"Analysis completed successfully.\nOptimal FWHM: {fwhm_result:.2f} mm\nResults saved to {savepath}")
        
        return True

#
# CAIATest
#

class CAIATest(ScriptedLoadableModuleTest):
    """
    Test case for the CAIA module
    """
    
    def setUp(self):
        """ Do whatever is needed to reset the state - typically a scene clear will be enough. """
        slicer.mrmlScene.Clear(0)

    def runTest(self):
        """Run as few or as many tests as needed here."""
        self.setUp()
        self.test_CAIA1()

    def test_CAIA1(self):
        """ Test the basic functionality of the CAIA module. """
        self.delayDisplay("Starting the test")
        
        # Create test volumes
        testVolumeNode = slicer.mrmlScene.AddNewNodeByClass('vtkMRMLScalarVolumeNode', 'TestVolume')
        testIdealVolumeNode = slicer.mrmlScene.AddNewNodeByClass('vtkMRMLScalarVolumeNode', 'TestIdealVolume')
        testMaskNode = slicer.mrmlScene.AddNewNodeByClass('vtkMRMLLabelMapVolumeNode', 'TestMask')
        testLabelVolumeNode = slicer.mrmlScene.AddNewNodeByClass('vtkMRMLLabelMapVolumeNode', 'TestLabelVolume')
        testCT_RefNode = slicer.mrmlScene.AddNewNodeByClass('vtkMRMLScalarVolumeNode', 'TestCT_Ref')
        testCT_NewNode = slicer.mrmlScene.AddNewNodeByClass('vtkMRMLScalarVolumeNode', 'TestCT_New')
        
        # Create simple volumes (10x10x10)
        import numpy as np
        imageSize = [10, 10, 10]
        imageSpacing = [1.0, 1.0, 1.0]
        imageOrigin = [0.0, 0.0, 0.0]
        
        # Create test image
        testImage = np.zeros(imageSize, dtype=np.float32)
        testImage[4:8, 4:8, 4:8] = 100  # Create a simple cubic signal
        
        # Create ideal image (similar but with different intensity)
        testIdealImage = np.zeros(imageSize, dtype=np.float32)
        testIdealImage[4:8, 4:8, 4:8] = 150  # Create a simple cubic signal
        
        # Create mask (binary)
        testMask = np.zeros(imageSize, dtype=np.uint8)
        testMask[3:9, 3:9, 3:9] = 1  # Slightly larger than the signal
        
        # Create label (multiple labels)
        testLabel = np.zeros(imageSize, dtype=np.uint8)
        testLabel[4:6, 4:6, 4:6] = 1  # First sphere
        testLabel[6:8, 6:8, 6:8] = 2  # Second sphere
        
        # Create CT reference
        testCT_Ref = np.zeros(imageSize, dtype=np.float32)
        testCT_Ref[3:9, 3:9, 3:9] = 500  # Create a simple cubic high-density region
        
        # Create CT new (slightly shifted)
        testCT_New = np.zeros(imageSize, dtype=np.float32)
        testCT_New[4:10, 3:9, 3:9] = 500  # Create a shifted high-density region
        
        # Set the volumes
        slicer.util.updateVolumeFromArray(testVolumeNode, testImage)
        slicer.util.updateVolumeFromArray(testIdealVolumeNode, testIdealImage)
        slicer.util.updateVolumeFromArray(testMaskNode, testMask)
        slicer.util.updateVolumeFromArray(testLabelVolumeNode, testLabel)
        slicer.util.updateVolumeFromArray(testCT_RefNode, testCT_Ref)
        slicer.util.updateVolumeFromArray(testCT_NewNode, testCT_New)
        
        # Set the proper spacing and origin
        for node in [testVolumeNode, testIdealVolumeNode, testMaskNode, testLabelVolumeNode, testCT_RefNode, testCT_NewNode]:
            node.SetSpacing(*imageSpacing)
            node.SetOrigin(*imageOrigin)
        
        # Create output directory
        import tempfile
        outputDir = tempfile.mkdtemp()
        
        # Create and set up the widget
        moduleWidget = slicer.modules.caia.widgetRepresentation()
        moduleWidget.inputSelectorNuclMedImgRaw.setCurrentNode(testVolumeNode)
        moduleWidget.inputSelectorNuclMedImgIdeal.setCurrentNode(testIdealVolumeNode)
        moduleWidget.inputSelectorMaskImg.setCurrentNode(testMaskNode)
        moduleWidget.inputSelectorLabelVolumeIdeal.setCurrentNode(testLabelVolumeNode)
        moduleWidget.inputSelectorCT_Ref.setCurrentNode(testCT_RefNode)
        moduleWidget.inputSelectorCT_New.setCurrentNode(testCT_NewNode)
        moduleWidget.NomSerie.text = "TestSeries"
        moduleWidget.OutputDirectory.currentPath = outputDir
        moduleWidget.FWHM_borneInf.text = "3"
        moduleWidget.precision.text = "0.1"
        moduleWidget.Niteration.text = "10"
        moduleWidget.window_size.text = "5"
        moduleWidget.SphereNumber.text = "2"
        moduleWidget.ImageSamplingPercentage.text = "100"
        moduleWidget.ImageSamplingPercentageCT.text = "100"
        moduleWidget.volume_sphere.text = "1.0,1.0"
        
        # The widget should now be properly set up with test data
        # We'll test the registration functionality
        self.delayDisplay("Testing registration")
        logic = CAIALogic()
        
        try:
            result = logic.registration(
                testVolumeNode,
                testCT_RefNode,
                testCT_NewNode,
                100,  # ImageSamplingPercentageCT
                moduleWidget.NomSerie
            )
            # If no exception, assume success
            self.delayDisplay("Registration test passed")
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.delayDisplay(f"Registration test failed: {str(e)}", 2000)
            raise
        
        # Test the main analysis function
        self.delayDisplay("Testing analysis")
        try:
            result = logic.run(
                testVolumeNode,
                testIdealVolumeNode,
                testMaskNode,
                testLabelVolumeNode,
                "TestSeries",
                outputDir,
                3,  # FWHM_borneInf
                0.1,  # precision
                10,  # Niteration
                5,  # window_size
                2,  # SphereNumber
                100,  # ImageSamplingPercentage
                "1.0,1.0"  # volume_sphere
            )
            # If no exception, assume success
            self.delayDisplay("Analysis test passed")
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.delayDisplay(f"Analysis test failed: {str(e)}", 2000)
            raise
        
        self.delayDisplay('All tests passed!')